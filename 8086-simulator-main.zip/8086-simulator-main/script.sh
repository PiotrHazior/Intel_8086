# My first script
echo "Podaj wersję kernela"
uname -a
echo "Podaj wersję gita"
git --version

